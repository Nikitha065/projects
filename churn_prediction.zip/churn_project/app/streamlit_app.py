"""
streamlit_app.py
-----------------
Run locally with:
    pip install -r requirements.txt
    streamlit run app/streamlit_app.py

No manual pipeline steps needed -- on first launch this app auto-generates
the synthetic dataset, trains both models, and runs the ROI simulator if
outputs/ doesn't already contain them. This is what makes the app work
out of the box on a fresh cloud deploy (Streamlit Community Cloud,
Hugging Face Spaces, etc.), where the repo intentionally does NOT ship
data/*.csv or outputs/*.pkl (kept out of git to keep the repo small).

Interactive dashboard: pick a customer -> see churn risk, top drivers
(SHAP-style), and a retention recommendation with expected ROI.
"""

import json
import subprocess
import sys
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "data"))

OUT_DIR = ROOT / "outputs"
DATA_DIR = ROOT / "data"


def _run_step(label, cmd):
    result = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True)
    if result.returncode != 0:
        st.error(f"Setup step failed: {label}\n\n{result.stderr[-2000:]}")
        st.stop()


@st.cache_resource
def ensure_pipeline_ready():
    """
    Runs once per app session (cached across reruns/users via cache_resource).
    Regenerates data/model artifacts only if they're missing -- so on a
    fresh cloud deploy this bootstraps everything automatically, and on a
    machine where you already ran the scripts manually, it's a no-op.
    """
    steps_run = []

    if not (DATA_DIR / "customers.csv").exists():
        with st.spinner("First-time setup: generating dataset..."):
            _run_step("generate_data.py", [sys.executable, "data/generate_data.py", "--n", "6000", "--seed", "42"])
        steps_run.append("data")

    if not (OUT_DIR / "model_config.json").exists():
        with st.spinner("First-time setup: training model (this takes ~10-20s)..."):
            _run_step("train_model.py", [sys.executable, "src/train_model.py"])
        steps_run.append("model")

    if not (OUT_DIR / "customers_scored.csv").exists():
        with st.spinner("First-time setup: running ROI simulator..."):
            _run_step("roi_simulator.py", [sys.executable, "src/roi_simulator.py", "--discount_cost", "50"])
        steps_run.append("roi")

    return steps_run


st.set_page_config(page_title="Churn Risk & Retention ROI", layout="wide")

_bootstrap_status = ensure_pipeline_ready()

from explain import load_artifacts, explain_customer  # noqa: E402
from train_generic import train_generic, explain_row  # noqa: E402


@st.cache_data
def load_data():
    scored_path = OUT_DIR / "customers_scored.csv"
    if scored_path.exists():
        df = pd.read_csv(scored_path)
    else:
        df = pd.read_csv(ROOT / "data" / "customers.csv")
    return df


@st.cache_data
def load_metrics():
    with open(OUT_DIR / "metrics.json") as f:
        return json.load(f)


cfg, raw_df = load_artifacts()
df = load_data()
metrics = load_metrics()

st.title("Customer Churn Risk & Retention ROI")
st.caption(
    "Predict churn, explain why, and decide who's actually worth offering a discount to."
)

tab_overview, tab_customer, tab_campaign, tab_upload = st.tabs(
    ["Model performance", "Customer lookup", "Campaign simulator", "Use your own data"]
)

# ---------------- Tab 1: Model performance ----------------
with tab_overview:
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Logistic Regression (interpretable)")
        st.json(metrics["logistic_regression"])
    with col2:
        st.subheader("Gradient Boosting (benchmark)")
        st.json(metrics["gradient_boosting"])

    st.markdown(
        f"""
        **Base churn rate (test set):** {metrics['base_churn_rate_test_set']:.1%}
        **Lift at top 10% riskiest customers:** {metrics['logistic_regression']['lift_at_top_10pct']}x
        the base rate — i.e. targeting just the top decile catches over 3x as many
        actual churners as a random sample would.
        """
    )

# ---------------- Tab 2: Customer lookup ----------------
with tab_customer:
    customer_id = st.selectbox("Select a customer", raw_df["customer_id"].tolist())
    result = explain_customer(customer_id, cfg, raw_df)

    c1, c2 = st.columns([1, 2])
    with c1:
        st.metric("Churn probability", f"{result['churn_probability']:.1%}")
        row = df[df["customer_id"] == customer_id].iloc[0]
        if "expected_value_of_offer" in row:
            rec = "Offer retention discount" if row["expected_value_of_offer"] > 0 else "Do not offer"
            st.metric("Recommendation", rec)
            st.metric("Expected value of offer", f"${row['expected_value_of_offer']:.2f}")

    with c2:
        drivers = result["top_drivers"]
        fig = go.Figure(go.Bar(
            x=[d["contribution"] for d in drivers][::-1],
            y=[d["feature"] for d in drivers][::-1],
            orientation="h",
            marker_color=["#c0392b" if d["contribution"] > 0 else "#2874a6" for d in drivers][::-1],
        ))
        fig.update_layout(
            title="Top drivers of this customer's churn risk (SHAP-style, red = increases risk)",
            xaxis_title="Contribution to churn logit",
            height=320, margin=dict(l=10, r=10, t=40, b=10),
        )
        st.plotly_chart(fig, use_container_width=True)

# ---------------- Tab 3: Campaign simulator ----------------
with tab_campaign:
    discount_cost = st.slider("Retention discount cost ($)", 10, 200, 50, step=5)

    if "uplift" in df.columns:
        df["expected_value_of_offer_live"] = df["uplift"] * df["ltv_estimate"] - discount_cost
        n_targeted = (df["expected_value_of_offer_live"] > 0).sum()
        total_ev = df.loc[df["expected_value_of_offer_live"] > 0, "expected_value_of_offer_live"].sum()
        blanket_ev = df["expected_value_of_offer_live"].sum()

        m1, m2, m3 = st.columns(3)
        m1.metric("Customers to target", f"{n_targeted:,}")
        m2.metric("Expected value (targeted)", f"${total_ev:,.0f}")
        m3.metric("Expected value (offer everyone)", f"${blanket_ev:,.0f}",
                   delta=f"{total_ev - blanket_ev:,.0f} worse" if blanket_ev < total_ev else None)

        st.dataframe(
            df.sort_values("expected_value_of_offer_live", ascending=False)
              .head(25)[["customer_id", "uplift", "ltv_estimate",
                         "expected_value_of_offer_live", "contract_type", "plan_tier"]],
            use_container_width=True,
        )
    else:
        st.info("Run `python src/roi_simulator.py` first to generate campaign scoring.")

# ---------------- Tab 4: Use your own data ----------------
with tab_upload:
    st.markdown(
        "Upload your own churn dataset (any schema). Pick which column is the "
        "churn label and which columns are features, and this trains a fresh "
        "model on YOUR data -- separate from the synthetic demo above."
    )

    uploaded = st.file_uploader("Upload a CSV", type="csv")

    if uploaded is not None:
        user_df = pd.read_csv(uploaded)
        st.write(f"Loaded {len(user_df)} rows, {len(user_df.columns)} columns.")
        st.dataframe(user_df.head(), use_container_width=True)

        all_cols = user_df.columns.tolist()

        target_col = st.selectbox(
            "Which column is the churn label? (e.g. 'Churn', 'churned', 'left')",
            all_cols,
        )

        remaining_cols = [c for c in all_cols if c != target_col]

        suggested_numeric = [
            c for c in remaining_cols
            if pd.api.types.is_numeric_dtype(user_df[c])
        ]
        suggested_categorical = [
            c for c in remaining_cols
            if not pd.api.types.is_numeric_dtype(user_df[c])
        ]

        numeric_cols = st.multiselect(
            "Numeric feature columns", remaining_cols, default=suggested_numeric
        )
        categorical_cols = st.multiselect(
            "Categorical feature columns",
            [c for c in remaining_cols if c not in numeric_cols],
            default=[c for c in suggested_categorical if c not in numeric_cols],
        )

        if st.button("Train model on this data"):
            try:
                with st.spinner("Training..."):
                    result = train_generic(
                        user_df, target_col=target_col,
                        numeric_cols=numeric_cols, categorical_cols=categorical_cols,
                    )
                st.session_state["custom_result"] = result
                st.session_state["custom_df"] = user_df
                st.success("Model trained.")
            except Exception as e:
                st.error(f"Training failed: {e}")

    if "custom_result" in st.session_state:
        result = st.session_state["custom_result"]
        st.subheader("Performance on your data (held-out test set)")
        st.json(result["metrics"])

        st.subheader("Top global drivers")
        coefs = sorted(result["coefficients"].items(), key=lambda x: -abs(x[1]))[:10]
        fig = go.Figure(go.Bar(
            x=[c[1] for c in coefs][::-1], y=[c[0] for c in coefs][::-1],
            orientation="h",
            marker_color=["#c0392b" if c[1] > 0 else "#2874a6" for c in coefs][::-1],
        ))
        fig.update_layout(height=350, margin=dict(l=10, r=10, t=10, b=10),
                           xaxis_title="Standardized coefficient")
        st.plotly_chart(fig, use_container_width=True)

        st.subheader("Score an individual row from your data")
        user_df = st.session_state["custom_df"]
        row_idx = st.number_input("Row index", 0, len(user_df) - 1, 0)
        row = user_df.iloc[int(row_idx)]

        row_features = {}
        for col in result["feature_cols"]:
            if col in user_df.columns:
                row_features[col] = float(row[col]) if pd.api.types.is_numeric_dtype(user_df[col]) else 0.0
            else:
                # one-hot encoded column, e.g. "Contract_One year"
                for cat_col in categorical_cols if uploaded is not None else []:
                    if col.startswith(f"{cat_col}_"):
                        val = col[len(cat_col) + 1:]
                        row_features[col] = 1.0 if str(row.get(cat_col)) == val else 0.0

        prob, drivers = explain_row(row_features, result["model_config"])
        st.metric("Churn probability", f"{prob:.1%}")
        for d in drivers:
            st.write(f"- **{d['feature']}**: {d['contribution']:+.3f} ({d['direction']})")
