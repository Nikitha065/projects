"""
train_generic.py
-----------------
A dataset-agnostic version of train_model.py's logic. Instead of assuming
the specific synthetic schema, this takes:
    - a DataFrame
    - a target column (binary: 1 = churned/left, 0 = stayed)
    - a list of numeric feature columns
    - a list of categorical feature columns

...and trains + evaluates a logistic regression the same way train_model.py
does (StandardScaler + class_weight='balanced' + lift/gain metrics), so
the SAME explainability math in explain.py's linear-SHAP decomposition
works on it unchanged.

This is what powers the "Use your own data" tab in the Streamlit app,
and can also be called directly:

    from train_generic import train_generic
    result = train_generic(df, target_col="Churn",
                            numeric_cols=["tenure", "MonthlyCharges"],
                            categorical_cols=["Contract", "PaymentMethod"])
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def lift_at_k(y_true, y_score, k_pct=0.10):
    n = len(y_true)
    k = max(1, int(n * k_pct))
    order = np.argsort(-y_score)
    top_k_true = np.array(y_true)[order[:k]]
    base_rate = np.mean(y_true)
    return float(np.mean(top_k_true) / base_rate) if base_rate > 0 else float("nan")


def coerce_binary_target(series):
    """Handle common encodings: 0/1, True/False, 'Yes'/'No', 'Churn'/'Stayed'."""
    if series.dtype == bool:
        return series.astype(int)
    if series.dtype in (int, float):
        uniques = set(series.dropna().unique())
        if uniques <= {0, 1}:
            return series.astype(int)
    mapped = series.astype(str).str.strip().str.lower().map({
        "yes": 1, "no": 0, "true": 1, "false": 0,
        "churn": 1, "churned": 1, "stayed": 0, "retained": 0,
        "1": 1, "0": 0,
    })
    if mapped.isna().any():
        raise ValueError(
            f"Could not map target column to binary 0/1. "
            f"Unique values found: {series.unique()[:10]}"
        )
    return mapped.astype(int)


def train_generic(df, target_col, numeric_cols, categorical_cols, test_size=0.25, random_state=42):
    df = df.copy()

    y = coerce_binary_target(df[target_col])

    # median-impute numeric NaNs, track missingness as its own signal
    missing_flags = {}
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        if df[col].isna().any():
            flag_col = f"{col}_missing"
            df[flag_col] = df[col].isna().astype(int)
            missing_flags[col] = flag_col
            df[col] = df[col].fillna(df[col].median())

    df_enc = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

    feature_cols = (
        numeric_cols
        + list(missing_flags.values())
        + [c for c in df_enc.columns if any(c.startswith(f"{cat}_") for cat in categorical_cols)]
    )

    X = df_enc[feature_cols].astype(float)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state,
        stratify=y if y.nunique() == 2 and y.value_counts().min() >= 2 else None,
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = LogisticRegression(class_weight="balanced", max_iter=2000, random_state=random_state)
    model.fit(X_train_scaled, y_train)

    proba = model.predict_proba(X_test_scaled)[:, 1]
    pred = (proba >= 0.5).astype(int)

    metrics = {
        "precision": round(precision_score(y_test, pred, zero_division=0), 4),
        "recall": round(recall_score(y_test, pred, zero_division=0), 4),
        "f1": round(f1_score(y_test, pred, zero_division=0), 4),
        "roc_auc": round(roc_auc_score(y_test, proba), 4) if y_test.nunique() == 2 else None,
        "lift_at_top_10pct": round(lift_at_k(y_test, proba, 0.10), 3),
        "base_rate": round(float(y_test.mean()), 4),
        "n_train": len(X_train),
        "n_test": len(X_test),
    }

    model_config = {
        "feature_order": feature_cols,
        "scaler_mean": scaler.mean_.round(6).tolist(),
        "scaler_scale": scaler.scale_.round(6).tolist(),
        "lr_coefficients": model.coef_[0].round(6).tolist(),
        "lr_intercept": float(model.intercept_[0]),
        "numeric_cols_with_missing": missing_flags,
    }

    coefficients = dict(zip(feature_cols, model.coef_[0].round(4).tolist()))

    return {
        "model": model,
        "scaler": scaler,
        "metrics": metrics,
        "model_config": model_config,
        "coefficients": coefficients,
        "feature_cols": feature_cols,
    }


def explain_row(row_features_dict, model_config, top_k=5):
    """Same closed-form linear-SHAP decomposition as explain.py, generalized."""
    feature_order = model_config["feature_order"]
    x = np.array([row_features_dict.get(f, 0.0) for f in feature_order])
    mean = np.array(model_config["scaler_mean"])
    scale = np.array(model_config["scaler_scale"])
    x_scaled = (x - mean) / scale

    coefs = np.array(model_config["lr_coefficients"])
    contributions = coefs * x_scaled
    logit = float(contributions.sum() + model_config["lr_intercept"])
    prob = 1 / (1 + np.exp(-logit))

    pairs = sorted(zip(feature_order, contributions.tolist()), key=lambda t: -abs(t[1]))
    top_drivers = [
        {"feature": f, "contribution": round(c, 4),
         "direction": "increases risk" if c > 0 else "decreases risk"}
        for f, c in pairs[:top_k]
    ]
    return round(prob, 4), top_drivers
