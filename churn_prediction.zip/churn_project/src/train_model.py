"""
train_model.py
---------------
Trains two churn models on data/customers.csv:

1. Logistic Regression (standardized features) -- inherently interpretable,
   used both as an evaluation baseline AND as the model whose coefficients
   power the SHAP-style additive explanations and the live browser demo
   (its math is simple enough to re-implement exactly in JavaScript for a
   true real-time interactive widget with no server required).

2. Gradient Boosting Classifier -- the higher-capacity benchmark model,
   representing what you'd ship in production if only raw performance
   mattered. Comparing the two is itself a good interview talking point:
   "I chose interpretability over the last 2 points of AUC because this
   model drives customer-facing retention offers."

Handles class imbalance the same way as a fraud-detection project would:
class_weight='balanced' (no SMOTE dependency needed, but the option is
noted in the README for parity with imbalanced-learn workflows).

Outputs (all in outputs/):
    logreg_model.pkl, gbm_model.pkl, scaler.pkl
    metrics.json              -- precision/recall/F1/ROC-AUC/lift for both models
    feature_importance.json   -- GBM importances + LR coefficients
    model_config.json         -- exact means/stds/coefficients so the JS
                                  browser demo can reproduce logit scoring
"""

import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    precision_score, recall_score, f1_score, roc_auc_score, roc_curve
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "customers.csv"
OUT_DIR = ROOT / "outputs"
OUT_DIR.mkdir(exist_ok=True)

NUMERIC_FEATURES = [
    "tenure_months", "monthly_charges", "login_freq_per_month",
    "feature_adoption_score", "support_tickets_90d", "unresolved_ticket",
    "late_payments_90d", "satisfaction_score", "auto_renew",
]
CATEGORICAL_FEATURES = ["contract_type", "plan_tier"]


def load_and_prepare():
    df = pd.read_csv(DATA_PATH)
    # median-impute the missing satisfaction survey responses; add a
    # "did not respond" flag since non-response is itself informative
    df["satisfaction_missing"] = df["satisfaction_score"].isna().astype(int)
    df["satisfaction_score"] = df["satisfaction_score"].fillna(
        df["satisfaction_score"].median()
    )

    df_enc = pd.get_dummies(
        df, columns=CATEGORICAL_FEATURES, drop_first=True
    )

    feature_cols = (
        NUMERIC_FEATURES
        + ["satisfaction_missing"]
        + [c for c in df_enc.columns if c.startswith("contract_type_") or c.startswith("plan_tier_")]
    )
    X = df_enc[feature_cols].astype(float)
    y = df_enc["churned"].astype(int)
    return df, X, y, feature_cols


def lift_at_k(y_true, y_score, k_pct=0.10):
    n = len(y_true)
    k = max(1, int(n * k_pct))
    order = np.argsort(-y_score)
    top_k_true = np.array(y_true)[order[:k]]
    base_rate = np.mean(y_true)
    top_k_rate = np.mean(top_k_true)
    return float(top_k_rate / base_rate) if base_rate > 0 else float("nan")


def main():
    df, X, y, feature_cols = load_and_prepare()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # ---- Model 1: Logistic Regression (interpretable, imbalance-aware) ----
    logreg = LogisticRegression(
        class_weight="balanced", max_iter=2000, random_state=42
    )
    logreg.fit(X_train_scaled, y_train)
    lr_proba = logreg.predict_proba(X_test_scaled)[:, 1]
    lr_pred = (lr_proba >= 0.5).astype(int)

    # ---- Model 2: Gradient Boosting (higher-capacity benchmark) ----
    gbm = GradientBoostingClassifier(
        n_estimators=250, max_depth=3, learning_rate=0.05, random_state=42
    )
    # GBM has no native class_weight; emulate via sample_weight
    sample_weight = np.where(y_train == 1, (y_train == 0).sum() / (y_train == 1).sum(), 1.0)
    gbm.fit(X_train, y_train, sample_weight=sample_weight)
    gbm_proba = gbm.predict_proba(X_test)[:, 1]
    gbm_pred = (gbm_proba >= 0.5).astype(int)

    def eval_block(y_true, y_pred, y_proba):
        return {
            "precision": round(precision_score(y_true, y_pred), 4),
            "recall": round(recall_score(y_true, y_pred), 4),
            "f1": round(f1_score(y_true, y_pred), 4),
            "roc_auc": round(roc_auc_score(y_true, y_proba), 4),
            "lift_at_top_10pct": round(lift_at_k(y_true, y_proba, 0.10), 3),
            "lift_at_top_20pct": round(lift_at_k(y_true, y_proba, 0.20), 3),
        }

    metrics = {
        "logistic_regression": eval_block(y_test, lr_pred, lr_proba),
        "gradient_boosting": eval_block(y_test, gbm_pred, gbm_proba),
        "base_churn_rate_test_set": round(float(y_test.mean()), 4),
        "n_train": len(X_train),
        "n_test": len(X_test),
    }

    # ---- Feature importance / coefficients ----
    lr_coefs = dict(zip(feature_cols, logreg.coef_[0].round(4).tolist()))
    gbm_importances = dict(zip(feature_cols, gbm.feature_importances_.round(4).tolist()))

    feature_importance = {
        "logistic_regression_coefficients": lr_coefs,
        "gradient_boosting_importances": dict(
            sorted(gbm_importances.items(), key=lambda x: -x[1])
        ),
    }

    # ---- model_config.json: everything needed to reproduce LR scoring in JS ----
    model_config = {
        "feature_order": feature_cols,
        "scaler_mean": scaler.mean_.round(6).tolist(),
        "scaler_scale": scaler.scale_.round(6).tolist(),
        "lr_coefficients": logreg.coef_[0].round(6).tolist(),
        "lr_intercept": float(logreg.intercept_[0]),
    }

    # ---- persist everything ----
    with open(OUT_DIR / "logreg_model.pkl", "wb") as f:
        pickle.dump(logreg, f)
    with open(OUT_DIR / "gbm_model.pkl", "wb") as f:
        pickle.dump(gbm, f)
    with open(OUT_DIR / "scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)
    with open(OUT_DIR / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    with open(OUT_DIR / "feature_importance.json", "w") as f:
        json.dump(feature_importance, f, indent=2)
    with open(OUT_DIR / "model_config.json", "w") as f:
        json.dump(model_config, f, indent=2)

    print(json.dumps(metrics, indent=2))
    print(f"\nSaved models + configs to {OUT_DIR}")


if __name__ == "__main__":
    main()
