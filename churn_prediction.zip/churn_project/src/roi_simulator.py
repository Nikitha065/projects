"""
roi_simulator.py
-----------------
Turns churn probability into a business decision using two pieces:

1. UPLIFT MODEL (T-learner): the synthetic dataset includes a real
   historical experiment -- 35% of customers were randomly offered a
   retention discount last quarter, and we observed whether they stayed.
   We train two separate models:
       model_treated   -- P(stay | features, was offered discount)
       model_control    -- P(stay | features, was NOT offered discount)
   uplift(customer) = model_treated(x) - model_control(x)
   This estimates *who the discount actually persuades* -- as opposed to
   customers who would have stayed anyway ("sure things") or who will
   leave regardless ("lost causes"). Targeting by uplift instead of by
   raw churn risk is the single biggest lever real retention teams miss.

2. ROI SIMULATOR: given an intervention cost and each customer's LTV,
   compute expected value of offering the discount:
       EV = uplift(customer) * LTV(customer) - cost_of_offer
   Only intervene where EV > 0.

Run:
    python roi_simulator.py --discount_cost 50 --top_n 15
"""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / "outputs"

NUMERIC_FEATURES = [
    "tenure_months", "monthly_charges", "login_freq_per_month",
    "feature_adoption_score", "support_tickets_90d", "unresolved_ticket",
    "late_payments_90d", "auto_renew",
]
CATEGORICAL_FEATURES = ["contract_type", "plan_tier"]


def prepare_features(df):
    df = df.copy()
    df["satisfaction_score"] = df["satisfaction_score"].fillna(df["satisfaction_score"].median())
    df_enc = pd.get_dummies(df, columns=CATEGORICAL_FEATURES, drop_first=True)
    feature_cols = (
        NUMERIC_FEATURES + ["satisfaction_score"]
        + [c for c in df_enc.columns if c.startswith("contract_type_") or c.startswith("plan_tier_")]
    )
    return df_enc[feature_cols].astype(float), feature_cols


def train_uplift_model():
    df = pd.read_csv(ROOT / "data" / "customers.csv")
    X_all, feature_cols = prepare_features(df)

    treated_mask = df["was_offered_discount"] == 1
    control_mask = df["was_offered_discount"] == 0

    y_treated = 1 - df.loc[treated_mask, "churned"]   # "stayed"
    y_control = 1 - df.loc[control_mask, "churned"]

    scaler = StandardScaler().fit(X_all)
    X_treated = scaler.transform(X_all[treated_mask])
    X_control = scaler.transform(X_all[control_mask])

    model_treated = LogisticRegression(max_iter=2000, random_state=42).fit(X_treated, y_treated)
    model_control = LogisticRegression(max_iter=2000, random_state=42).fit(X_control, y_control)

    X_all_scaled = scaler.transform(X_all)
    p_stay_treated = model_treated.predict_proba(X_all_scaled)[:, 1]
    p_stay_control = model_control.predict_proba(X_all_scaled)[:, 1]
    uplift = p_stay_treated - p_stay_control  # positive = discount helps retention

    df["p_stay_if_offered"] = p_stay_treated.round(4)
    df["p_stay_if_not_offered"] = p_stay_control.round(4)
    df["uplift"] = uplift.round(4)

    return df, feature_cols


def compute_ltv(df, monthly_margin_pct=0.55, horizon_months=24):
    """Simple LTV proxy: monthly_charges * margin * expected remaining months."""
    remaining = np.clip(horizon_months - (df["tenure_months"] % horizon_months), 3, horizon_months)
    return (df["monthly_charges"] * monthly_margin_pct * remaining).round(2)


def simulate(discount_cost=50.0, top_n=15):
    df, feature_cols = train_uplift_model()
    df["ltv_estimate"] = compute_ltv(df)

    df["expected_value_of_offer"] = (df["uplift"] * df["ltv_estimate"] - discount_cost).round(2)
    df["recommend_offer"] = df["expected_value_of_offer"] > 0

    segment_summary = (
        df.assign(
            segment=np.select(
                [
                    (df["uplift"] > 0.05) & (df["p_stay_if_not_offered"] < 0.85),
                    (df["uplift"] <= 0.05) & (df["p_stay_if_not_offered"] >= 0.9),
                    (df["uplift"] < 0.0),
                ],
                ["Persuadable (target)", "Sure thing (skip)", "Sleeping dog (skip)"],
                default="Low-impact (skip)",
            )
        )
        .groupby("segment")
        .agg(
            n_customers=("customer_id", "count"),
            avg_uplift=("uplift", "mean"),
            avg_ltv=("ltv_estimate", "mean"),
            total_recommended_ev=("expected_value_of_offer", lambda s: s[s > 0].sum()),
        )
        .round(3)
        .reset_index()
    )

    top_targets = (
        df[df["recommend_offer"]]
        .sort_values("expected_value_of_offer", ascending=False)
        .head(top_n)[[
            "customer_id", "churned", "uplift", "ltv_estimate",
            "expected_value_of_offer", "contract_type", "plan_tier",
        ]]
    )

    return df, segment_summary, top_targets


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--discount_cost", type=float, default=50.0)
    parser.add_argument("--top_n", type=int, default=15)
    args = parser.parse_args()

    df, segment_summary, top_targets = simulate(args.discount_cost, args.top_n)

    print("=== Segment summary ===")
    print(segment_summary.to_string(index=False))
    print(f"\n=== Top {args.top_n} highest-EV customers to target ===")
    print(top_targets.to_string(index=False))

    total_ev = df.loc[df["recommend_offer"], "expected_value_of_offer"].sum()
    n_targeted = df["recommend_offer"].sum()
    print(f"\nRecommended campaign: target {n_targeted} customers, "
          f"total expected value = ${total_ev:,.2f} "
          f"(vs. offering everyone: "
          f"${(df['uplift'] * df['ltv_estimate'] - args.discount_cost).sum():,.2f})")

    df.to_csv(OUT_DIR / "customers_scored.csv", index=False)
    segment_summary.to_json(OUT_DIR / "segment_summary.json", orient="records", indent=2)
    print(f"\nSaved scored dataset -> {OUT_DIR/'customers_scored.csv'}")
