"""
explain.py
----------
Produces per-customer explanations for the churn model.

Note on methodology: for a linear/logistic model, the exact Shapley-value
decomposition of the logit collapses to a simple closed form --
    contribution_i = coefficient_i * standardized_value_i
This is not an approximation; it IS the SHAP value for a linear model
(see Lundberg & Lee, 2017, sec. "Linear SHAP"). That's why the logistic
regression was kept in the pipeline even though the GBM scores similarly:
it gives exact, cheap, real-time explanations with no extra dependency.

If the `shap` package is available in your environment, swap in
`shap.TreeExplainer(gbm)` for the gradient boosting model to get the same
style of explanation for the higher-capacity model -- the rest of this
pipeline (ROI simulator, dashboard) does not need to change.

Run:
    python explain.py --customer_id CUST100005
    python explain.py --top_n 25       # dumps explanations for N riskiest customers
"""

import argparse
import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / "outputs"


def load_artifacts():
    with open(OUT_DIR / "model_config.json") as f:
        cfg = json.load(f)
    df = pd.read_csv(ROOT / "data" / "customers.csv")
    return cfg, df


def build_feature_row(row, feature_order):
    """Recreate the exact one-hot/derived feature vector used at train time."""
    d = {
        "tenure_months": row["tenure_months"],
        "monthly_charges": row["monthly_charges"],
        "login_freq_per_month": row["login_freq_per_month"],
        "feature_adoption_score": row["feature_adoption_score"],
        "support_tickets_90d": row["support_tickets_90d"],
        "unresolved_ticket": row["unresolved_ticket"],
        "late_payments_90d": row["late_payments_90d"],
        "satisfaction_score": row["satisfaction_score"] if not pd.isna(row["satisfaction_score"]) else np.nan,
        "auto_renew": row["auto_renew"],
        "satisfaction_missing": int(pd.isna(row["satisfaction_score"])),
        "contract_type_Month-to-month": int(row["contract_type"] == "Month-to-month"),
        "contract_type_One year": int(row["contract_type"] == "One year"),
        "contract_type_Two year": int(row["contract_type"] == "Two year"),
        "plan_tier_Basic": int(row["plan_tier"] == "Basic"),
        "plan_tier_Enterprise": int(row["plan_tier"] == "Enterprise"),
        "plan_tier_Pro": int(row["plan_tier"] == "Pro"),
    }
    if pd.isna(d["satisfaction_score"]):
        d["satisfaction_score"] = 7.0  # median fallback, matches training imputation
    return np.array([d[f] for f in feature_order], dtype=float)


def explain_customer(customer_id, cfg, df, top_k=5):
    row = df[df["customer_id"] == customer_id]
    if row.empty:
        raise ValueError(f"customer_id {customer_id} not found")
    row = row.iloc[0]

    feature_order = cfg["feature_order"]
    x = build_feature_row(row, feature_order)
    mean = np.array(cfg["scaler_mean"])
    scale = np.array(cfg["scaler_scale"])
    x_scaled = (x - mean) / scale

    coefs = np.array(cfg["lr_coefficients"])
    contributions = coefs * x_scaled
    logit = float(contributions.sum() + cfg["lr_intercept"])
    prob = 1 / (1 + np.exp(-logit))

    contrib_pairs = sorted(
        zip(feature_order, contributions.tolist(), x.tolist()),
        key=lambda t: -abs(t[1])
    )

    top_drivers = [
        {"feature": f, "raw_value": v, "contribution": round(c, 4),
         "direction": "increases risk" if c > 0 else "decreases risk"}
        for f, c, v in contrib_pairs[:top_k]
    ]

    return {
        "customer_id": customer_id,
        "churn_probability": round(prob, 4),
        "intercept": round(cfg["lr_intercept"], 4),
        "top_drivers": top_drivers,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--customer_id", type=str, default=None)
    parser.add_argument("--top_n", type=int, default=None,
                         help="If set, explain the N riskiest customers instead")
    args = parser.parse_args()

    cfg, df = load_artifacts()

    if args.customer_id:
        result = explain_customer(args.customer_id, cfg, df)
        print(json.dumps(result, indent=2))
    else:
        n = args.top_n or 10
        # score everyone, take riskiest N
        scored = []
        for cid in df["customer_id"].sample(min(500, len(df)), random_state=1):
            scored.append(explain_customer(cid, cfg, df))
        scored.sort(key=lambda r: -r["churn_probability"])
        print(json.dumps(scored[:n], indent=2))
