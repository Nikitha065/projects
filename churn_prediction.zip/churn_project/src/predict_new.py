"""
predict_new.py
---------------
Score YOUR OWN customer data against the trained churn model.

Works two ways:

1. CSV mode -- point it at a CSV with the required columns, get back
   churn probability + top risk drivers for every row.

   python predict_new.py --csv my_customers.csv

2. Single customer mode -- pass values directly as command-line flags.

   python predict_new.py \
       --tenure_months 8 --monthly_charges 95 --login_freq_per_month 3 \
       --feature_adoption_score 0.2 --support_tickets_90d 4 \
       --unresolved_ticket 1 --late_payments_90d 2 --satisfaction_score 4.5 \
       --auto_renew 0 --contract_type "Month-to-month" --plan_tier "Basic"

Required columns / flags (CSV mode: these must be column headers exactly):
    tenure_months            int, months as a customer
    monthly_charges          float, $ per month
    login_freq_per_month     int, logins per month
    feature_adoption_score   float 0-1
    support_tickets_90d      int, tickets in last 90 days
    unresolved_ticket        0 or 1
    late_payments_90d        int
    satisfaction_score       float 0-10 (leave blank/NaN if unknown -- it will
                              be imputed and flagged automatically)
    auto_renew               0 or 1
    contract_type            one of: "Month-to-month", "One year", "Two year"
    plan_tier                one of: "Basic", "Pro", "Enterprise"

Only needs outputs/model_config.json -- no .pkl files or scikit-learn
model objects required, since a logistic regression's scoring is just
arithmetic once you have its coefficients.
"""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
CFG_PATH = ROOT / "outputs" / "model_config.json"

REQUIRED_COLS = [
    "tenure_months", "monthly_charges", "login_freq_per_month",
    "feature_adoption_score", "support_tickets_90d", "unresolved_ticket",
    "late_payments_90d", "satisfaction_score", "auto_renew",
    "contract_type", "plan_tier",
]


def load_config():
    with open(CFG_PATH) as f:
        return json.load(f)


def build_feature_vector(row, feature_order):
    sat = row.get("satisfaction_score")
    sat_missing = int(pd.isna(sat))
    sat_val = 7.0 if sat_missing else float(sat)  # matches training-time median imputation

    d = {
        "tenure_months": float(row["tenure_months"]),
        "monthly_charges": float(row["monthly_charges"]),
        "login_freq_per_month": float(row["login_freq_per_month"]),
        "feature_adoption_score": float(row["feature_adoption_score"]),
        "support_tickets_90d": float(row["support_tickets_90d"]),
        "unresolved_ticket": float(row["unresolved_ticket"]),
        "late_payments_90d": float(row["late_payments_90d"]),
        "satisfaction_score": sat_val,
        "auto_renew": float(row["auto_renew"]),
        "satisfaction_missing": float(sat_missing),
        "contract_type_One year": float(row["contract_type"] == "One year"),
        "contract_type_Two year": float(row["contract_type"] == "Two year"),
        "plan_tier_Enterprise": float(row["plan_tier"] == "Enterprise"),
        "plan_tier_Pro": float(row["plan_tier"] == "Pro"),
    }
    return np.array([d[f] for f in feature_order])


def score(row, cfg, top_k=5):
    feature_order = cfg["feature_order"]
    x = build_feature_vector(row, feature_order)
    mean = np.array(cfg["scaler_mean"])
    scale = np.array(cfg["scaler_scale"])
    x_scaled = (x - mean) / scale

    coefs = np.array(cfg["lr_coefficients"])
    contributions = coefs * x_scaled
    logit = float(contributions.sum() + cfg["lr_intercept"])
    prob = 1 / (1 + np.exp(-logit))

    pairs = sorted(zip(feature_order, contributions.tolist()), key=lambda t: -abs(t[1]))
    top_drivers = [
        {"feature": f, "contribution": round(c, 4),
         "direction": "increases risk" if c > 0 else "decreases risk"}
        for f, c in pairs[:top_k]
    ]
    return round(prob, 4), top_drivers


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", type=str, default=None, help="Path to your own customer CSV")
    for col in REQUIRED_COLS:
        parser.add_argument(f"--{col}", type=str, default=None)
    args = parser.parse_args()

    cfg = load_config()

    if args.csv:
        df = pd.read_csv(args.csv)
        missing = [c for c in REQUIRED_COLS if c not in df.columns]
        if missing:
            raise ValueError(f"CSV is missing required columns: {missing}")

        results = []
        for _, row in df.iterrows():
            prob, drivers = score(row, cfg)
            results.append({**row.to_dict(), "churn_probability": prob,
                             "top_driver": drivers[0]["feature"] if drivers else None})
        out_df = pd.DataFrame(results)
        out_path = Path(args.csv).with_name(Path(args.csv).stem + "_scored.csv")
        out_df.to_csv(out_path, index=False)
        print(out_df[["churn_probability"]].describe())
        print(f"\nScored {len(out_df)} rows -> {out_path}")

    else:
        row = {}
        for col in REQUIRED_COLS:
            val = getattr(args, col)
            if val is None:
                raise ValueError(f"Missing required value: --{col}")
            row[col] = val
        for numeric_col in [c for c in REQUIRED_COLS if c not in ("contract_type", "plan_tier")]:
            row[numeric_col] = float(row[numeric_col])

        prob, drivers = score(row, cfg)
        print(f"Churn probability: {prob:.1%}\n")
        print("Top drivers:")
        for d in drivers:
            print(f"  {d['feature']:<28} {d['contribution']:+.3f}  ({d['direction']})")


if __name__ == "__main__":
    main()
