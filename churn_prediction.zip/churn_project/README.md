# Customer Churn Risk & Retention ROI Simulator

Predicts which customers will churn, explains *why* in plain terms, and
tells you which of those customers are actually worth spending a retention
budget on — because targeting everyone who's at risk isn't the same as
targeting everyone worth saving.

## Why this project (and how it differs from a typical churn tutorial)

Most churn portfolio projects stop at "here's an AUC of 0.82." This one adds
the two layers that make churn modeling useful in an actual company:

1. **Explainability that's exact, not approximate.** The logistic regression's
   per-customer contributions are the closed-form Shapley decomposition of a
   linear model (`contribution_i = coefficient_i × standardized_value_i`) —
   not a post-hoc approximation. Fast enough to run in real time, in the
   browser, with no server.
2. **Uplift modeling, not just risk scoring.** A high churn-risk customer
   who'd leave regardless of any offer is a wasted discount. A T-learner
   uplift model (trained on a simulated historical A/B discount campaign)
   estimates who the offer actually *persuades*, and an ROI simulator only
   recommends intervening where expected value is positive.

On the included synthetic dataset, targeting by uplift + ROI instead of
blanket-offering a $50 discount to every at-risk customer turns a
**-$107,484 expected loss into a +$71,789 expected gain** — that swing is
the headline number for an interview.

## Project structure
```
churn_project/
├── data/
│   └── generate_data.py       # synthetic SaaS churn dataset + simulated campaign
├── src/
│   ├── train_model.py         # logistic regression + gradient boosting, imbalance-aware
│   ├── explain.py             # per-customer SHAP-equivalent explanations
│   └── roi_simulator.py       # T-learner uplift model + expected-value targeting
├── app/
│   └── streamlit_app.py       # interactive dashboard (customer lookup + campaign sim)
├── outputs/                   # generated metrics, models, scored customers
├── requirements.txt
└── README.md
```

## Run it locally
```bash
pip install -r requirements.txt

python data/generate_data.py --n 6000 --seed 42
python src/train_model.py
python src/roi_simulator.py --discount_cost 50
streamlit run app/streamlit_app.py
```

Or explain a single customer from the command line:
```bash
python src/explain.py --customer_id CUST100003
```

## Modeling choices worth mentioning in an interview

- **Why logistic regression alongside gradient boosting?** On this dataset
  they perform almost identically (AUC 0.786 vs 0.756) because the
  underlying churn signal is mostly linear/additive — a realistic outcome
  for subscription-business churn, and a good prompt to talk about when
  model complexity earns its keep and when it doesn't.
- **Why lift/gain instead of just accuracy?** Retention teams have a fixed
  number of outreach slots, not a fixed accuracy target. Lift at the top
  10% (~3.2x the base churn rate) answers "if I can only contact 10% of
  customers, how many actual churners do I catch?" — the metric that
  matters operationally.
- **Why class_weight='balanced' instead of SMOTE?** Same effect (correcting
  for the ~15% positive rate) without synthesizing feature vectors that
  don't correspond to real customers — worth defending either way, and an
  easy connection back to your fraud-detection project's imbalance handling.
- **Why a T-learner instead of just filtering by churn probability?** A high
  churn-risk customer with negative uplift (a "sleeping dog" whose behavior
  a discount offer could annoy rather than retain) is exactly who a naive
  risk-based campaign would target and waste money on.

## Extending it further
- Swap `shap.TreeExplainer` in for `explain.py`'s linear decomposition to
  get exact SHAP values on the gradient boosting model too.
- Replace the synthetic data with a real dataset (e.g. the Kaggle Telco
  Customer Churn set) — `train_model.py`'s feature list is the only thing
  that needs updating.
- Swap the T-learner for an X-learner or causal forest (`econml` /
  `causalml`) if the treatment and control groups are imbalanced in size.
