"""
generate_data.py
-----------------
Generates a realistic synthetic SaaS customer-churn dataset.

Why synthetic instead of Kaggle's Telco CSV?
- Fully reproducible or resizable to any n.
- Lets us bake in a *known* causal structure (support tickets, usage decay,
  contract type, price sensitivity) so model performance and SHAP-style
  explanations can be sanity-checked against ground truth.
- Includes a simulated historical retention campaign (a subset of customers
  were offered a discount) so we can build a real uplift model later --
  something the plain Telco Kaggle CSV does not support.

Run:
    python generate_data.py --n 6000 --seed 42
Outputs:
    data/customers.csv
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def generate(n=6000, seed=42):
    rng = np.random.default_rng(seed)

    customer_id = [f"CUST{100000+i}" for i in range(n)]

    tenure_months = rng.gamma(shape=2.0, scale=14, size=n).clip(1, 72).astype(int)

    contract_type = rng.choice(
        ["Month-to-month", "One year", "Two year"],
        size=n, p=[0.55, 0.28, 0.17]
    )

    monthly_charges = np.round(rng.normal(70, 25, size=n).clip(15, 180), 2)

    # usage engagement: logins per month, decays for at-risk customers later
    login_freq = rng.poisson(lam=14, size=n).clip(0, 60)

    # feature adoption score 0-1
    feature_adoption = rng.beta(2, 2, size=n)

    # support tickets in last 90 days, and whether the last one is unresolved
    support_tickets = rng.poisson(lam=1.2, size=n).clip(0, 15)
    unresolved_ticket = (rng.random(n) < (0.12 + 0.05 * (support_tickets > 2))).astype(int)

    # payment delay days (billing friction)
    late_payments = rng.poisson(lam=0.6, size=n).clip(0, 10)

    # NPS-style satisfaction survey score, 0-10, missing for ~30% (no response)
    satisfaction_score = rng.normal(7, 2, size=n).clip(0, 10)
    survey_missing = rng.random(n) < 0.30
    satisfaction_score = np.where(survey_missing, np.nan, np.round(satisfaction_score, 1))

    plan_tier = rng.choice(["Basic", "Pro", "Enterprise"], size=n, p=[0.45, 0.4, 0.15])

    auto_renew = rng.choice([1, 0], size=n, p=[0.7, 0.3])

    # ---- historical retention campaign (for uplift modeling) ----
    # 35% of customers were randomly offered a retention discount last quarter
    was_offered_discount = (rng.random(n) < 0.35).astype(int)

    # ---- TRUE latent churn risk (logit scale) -> ground truth signal ----
    logit = (
        -0.55
        - 0.030 * tenure_months
        + 0.018 * monthly_charges
        - 0.05 * login_freq
        - 1.1 * feature_adoption
        + 0.28 * support_tickets
        + 0.9 * unresolved_ticket
        + 0.35 * late_payments
        - 0.18 * np.nan_to_num(satisfaction_score, nan=7.0)
        - 0.55 * auto_renew
    )
    logit += np.where(contract_type == "Month-to-month", 0.75,
              np.where(contract_type == "One year", -0.15, -0.9))
    logit += np.where(plan_tier == "Enterprise", -0.35,
              np.where(plan_tier == "Basic", 0.15, 0.0))

    # Treatment effect: discount reduces churn probability, MORE for
    # price-sensitive / month-to-month customers, LESS for enterprise
    # (this heterogeneous effect is exactly what an uplift model should recover)
    treatment_effect = np.where(
        contract_type == "Month-to-month", -0.9,
        np.where(plan_tier == "Enterprise", -0.10, -0.45)
    )
    logit += was_offered_discount * treatment_effect

    # add noise
    logit += rng.normal(0, 0.6, size=n)

    churn_prob = 1 / (1 + np.exp(-logit))
    churned = (rng.random(n) < churn_prob).astype(int)

    # for customers who were offered a discount, "stayed_after_offer" is the
    # observed outcome of that historical campaign (used for uplift training)
    stayed_after_offer = np.where(was_offered_discount == 1, 1 - churned, np.nan)

    df = pd.DataFrame({
        "customer_id": customer_id,
        "tenure_months": tenure_months,
        "contract_type": contract_type,
        "plan_tier": plan_tier,
        "monthly_charges": monthly_charges,
        "login_freq_per_month": login_freq,
        "feature_adoption_score": np.round(feature_adoption, 3),
        "support_tickets_90d": support_tickets,
        "unresolved_ticket": unresolved_ticket,
        "late_payments_90d": late_payments,
        "satisfaction_score": satisfaction_score,
        "auto_renew": auto_renew,
        "was_offered_discount": was_offered_discount,
        "stayed_after_offer": stayed_after_offer,
        "churned": churned,
    })

    return df


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=6000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    df = generate(args.n, args.seed)
    out_path = Path(__file__).resolve().parent / "customers.csv"
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df)} rows -> {out_path}")
    print(f"Overall churn rate: {df['churned'].mean():.3f}")
    print(f"Customers with historical discount offer: {df['was_offered_discount'].sum()}")
